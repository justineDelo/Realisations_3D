﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Player : MonoBehaviour {

    public float Health { get; private set; }
    public bool isAlive { get; private set; }
    Rigidbody rigidBodyPlayer;
    [SerializeField] float startHealth =5; //number of life
    [SerializeField] float shipSpeed = 5; //translation speed of the ship
    [SerializeField] float shipTurnSpeed = 20; //rotation speed of the ship

    [SerializeField] GameObject missilePrefab;
    [SerializeField] Transform missileSpawnPoint;

    [SerializeField] Image healthBar;

    // Use this for initialization
    void Start () {
        //initialize life value
        Health = startHealth;
        isAlive = true;
	}
	
	// Update is called once per frame
	void Update () {
        //while we are alive, we can move and shoot
        if (isAlive)
        {
            ForwardMovement();
            RotationMovement();
            if (Input.GetKeyDown(KeyCode.Space))
            {
                Shoot();
            }
        }
        
	}

    void ForwardMovement()
    {
        transform.position += transform.forward * Input.GetAxis("Vertical") * Time.deltaTime * shipSpeed;
    }

    void RotationMovement()
    {
        float yaw = Input.GetAxis("Yaw") * shipTurnSpeed * Time.deltaTime;
        float roll = Input.GetAxis("Roll") * shipTurnSpeed * Time.deltaTime;
        float pitch = Input.GetAxis("Pitch") * shipTurnSpeed * Time.deltaTime;
        transform.Rotate(pitch, yaw, roll);
    }

    void Shoot()
    {
        GameObject missile = Instantiate(missilePrefab, missileSpawnPoint) as GameObject;
        missile.transform.parent = null;
    }

    public void TakeDamage(float damageTaken)
    {
        //lose life when hurting an asteroid
        Health -= damageTaken;
        if (Health <= 0)
        {
            isAlive = false; //if we do not have life left, it is the end we cannot move anymore
        }
        healthBar.fillAmount = Health / startHealth; //update the bar showing the life in the screen
    }

    private void OnCollisionEnter(Collision otherObject)
    {
        if(otherObject.gameObject.tag == "Asteroid" && otherObject.collider.enabled)
        {
            otherObject.collider.enabled = false;
            Destroy(otherObject.gameObject); //destroy the asteroid we hurt
            TakeDamage(2f); //lose life
        }
    }
}
