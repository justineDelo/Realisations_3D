﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AsteroidsManager : MonoBehaviour {

    [SerializeField] Asteroid asteroid;
    [SerializeField] int asteroidsPerAxis = 10;
    [SerializeField] int asteroidSpacing = 20;
    SphereCollider managerCollider;

    GameManager rules;

    void Start () {
        rules = GameObject.FindGameObjectWithTag("GameManager").GetComponent<GameManager>();
        managerCollider = GetComponent<SphereCollider>();
        PlaceAsteroid();
	}
	
	void Update () {
        managerCollider.center = rules.GetPlayerTransform().position;
	}

    void PlaceAsteroid()
    {
        //create the right number of asteroids
        for(int i=-asteroidsPerAxis/2; i<asteroidsPerAxis/2; i++)
        {
            for (int j = -asteroidsPerAxis / 2; j < asteroidsPerAxis / 2; j++)
            {
                for (int k = -asteroidsPerAxis / 2; k < asteroidsPerAxis / 2; k++)
                {
                    InstantiateAsteroid(i, j, k);
                }
            }
        }
            
    }

    void InstantiateAsteroid(int i, int j, int k)
    {
        //create asteroid in random positions
        Vector3 positionInstanciation = new Vector3(i + Random.Range(-asteroidSpacing / 2f, asteroidSpacing / 2f),
                                                    j + Random.Range(-asteroidSpacing / 2f, asteroidSpacing / 2f),
                                                    k + Random.Range(-asteroidSpacing / 2f, asteroidSpacing / 2f));
        
        Instantiate(asteroid, positionInstanciation* asteroidSpacing + transform.position, Quaternion.identity, transform);
    }

    private void OnTriggerExit(Collider other)
    {
        //if an asteroid goes out of the global sphere, we respawn it on the other side so that we reuse the previously created asteroids to populate our area when we move
        if(other.gameObject.tag == "Asteroid")
        {
            other.gameObject.transform.position = (2 * managerCollider.center - other.gameObject.transform.position);
        }
        //if a missile goes too far, destroy it 
        if (other.gameObject.tag == "Missile")
        {
            Destroy(other.gameObject);
        }

    }
}
