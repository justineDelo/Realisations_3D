﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FirstPersonCamera : MonoBehaviour {
    [SerializeField] Transform subject;
    [SerializeField] Vector3 defaultOffset = new Vector3(0,2,-10);
    [SerializeField] float interpolationFactor = 0.3f;

    Vector3 velocity = Vector3.one;
	
	// Update is called once per frame
	void LateUpdate () {
        //calcul de la position de la camera
        Vector3 nextPosition = subject.position + (subject.rotation * defaultOffset);

        //interpolation
        transform.position = Vector3.SmoothDamp(transform.position, nextPosition, ref velocity, interpolationFactor);

        //rotation
        transform.LookAt(subject,subject.up);
	}
}
