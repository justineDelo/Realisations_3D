﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Missile : MonoBehaviour {

    [SerializeField] int vitesseMissile = 150;
	// Use this for initialization
	void Start () {
        GetComponent<Rigidbody>().velocity += transform.forward * vitesseMissile;	
	}
	
	
	void Update () {
		
	}
    IEnumerator timerDelete(float time, GameObject objectToDelete)
    {
        //coroutine
        yield return new WaitForSeconds(time);
        Destroy(objectToDelete);
    }
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag == "Asteroid")
        {
            //we want to wait a little to see the bounce (funny) then destroy
        
            StartCoroutine(timerDelete(0.5f, collision.gameObject));
            StartCoroutine(timerDelete(0.5f, gameObject));
        }
    }
}
