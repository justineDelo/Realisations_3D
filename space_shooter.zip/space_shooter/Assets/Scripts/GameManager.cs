﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour {
    [SerializeField] GameObject player;

	// Use this for initialization
	void Start () {
		
	}
	
    public Transform GetPlayerTransform()
    {
        return player.transform;
    }

}
