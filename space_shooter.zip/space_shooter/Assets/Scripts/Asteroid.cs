﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Asteroid : MonoBehaviour {
    [SerializeField] float minscale = 3f; //size minimum for an asteroid
    [SerializeField] float maxscale = 3.5f; //size maximum for an asteroid

    [SerializeField] float angleRotation = 45;
    [SerializeField] float velocityValue = 0.7f;
    Vector3 rotation;
    Vector3 translation;

    Rigidbody asteroidRigidBody;

	
	void Start () {
        //random scale within the range
        transform.localScale = new Vector3(Random.Range(minscale, maxscale), Random.Range(minscale, maxscale), Random.Range(minscale, maxscale));
        //random rotation within the range
        rotation = new Vector3(Random.Range(-angleRotation, angleRotation), Random.Range(-angleRotation, angleRotation), Random.Range(-angleRotation, angleRotation));
        asteroidRigidBody = gameObject.GetComponent<Rigidbody>();
        //random velocity within the range
        translation = new Vector3(Random.Range(-velocityValue, velocityValue), Random.Range(-velocityValue, velocityValue), Random.Range(-velocityValue, velocityValue));
        asteroidRigidBody.velocity = translation;
    }

    
    void Update () {
        transform.Rotate(rotation * Time.deltaTime); //make it rotate
	}
}
